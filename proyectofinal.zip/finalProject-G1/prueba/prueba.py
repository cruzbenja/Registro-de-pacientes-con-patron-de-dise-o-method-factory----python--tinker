from registro import *

register()
